SELECT * FROM autos
SELECT * FROM cust
SELECT * FROM servicios

INSERT INTO autos (idc,marca,anio,custid)
VALUES (9,'3CV',4,1980)



INSERT INTO servicios(ids,idc,fecha,monto,detalle)
VALUES (7,9,0225,7500,'indicador nafta')




SELECT nombre,marca,anio
FROM cust INNER JOIN autos
ON id=idcust




SELECT marca,anio
from autos INNER JOIN servicios
ON idc1=idc
WHERE marca NOT IN (SELECT marca FROM autos)


SELECT marca from autos
WHERE marca NOT IN (SELECT marca
from autos INNER JOIN servicios
ON idc1=idc)
