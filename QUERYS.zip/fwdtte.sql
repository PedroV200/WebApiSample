CREATE TABLE fwdtte 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from fwdtte  




