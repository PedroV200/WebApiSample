CREATE TABLE polizas 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from polizas 




