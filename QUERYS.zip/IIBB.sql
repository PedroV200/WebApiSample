CREATE TABLE iibb 
(
	code INT PRIMARY KEY,
	id SERIAL,
	description char varying,
	coef float8,
	alicuota float8,
	factor float8
)

SELECT * FROM iibb


SELECT code from iibb WHERE description='Corrientes'

