CREATE TABLE depositos 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from depositos 




