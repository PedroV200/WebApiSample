CREATE TABLE custodia 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from custodia 




