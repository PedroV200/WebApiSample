

CREATE TABLE gastoslocales
(
	id SERIAL PRIMARY KEY,
	fwd	integer,
	gfwd float8,
	terminal integer,
	gterminal float8,
	despachante integer,
	gdespachante float8,
	ttelocal	integer,
	gttelocal	float8,
	cust integer,
	gcust float8,
	gestdigdocum integer,
	ggestdigdoc float8,
	bank integer,
	gbancarios float8,
	poliza	integer,
	gpoliza float8,
	extragastos1 float8,
	gextra1 float8,
	extragastos2 float8,
	gextra2 float8,
	extragastos3 float8,
	gextra3 float8
)


ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code1
FOREIGN KEy(fwd)
REFERENCES fwdtte(Id);

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code2
FOREIGN KEy(terminal)
REFERENCES terminal(Id);

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code3
FOREIGN KEy(despachante)
REFERENCES despachantes(Id);

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code4
FOREIGN KEy(ttelocal)
REFERENCES flete(Id);

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code5
FOREIGN KEy(cust)
REFERENCES custodia(Id);

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code6
FOREIGN KEy(gestdigdocum)
REFERENCES gestdigdoc(Id)

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code7
FOREIGN KEy(bank)
REFERENCES banco(Id);

ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code8
FOREIGN KEy(poliza)
REFERENCES polizas(Id);


ALTER TABLE gastoslocales
ADD CONSTRAINT pk_code9
FOREIGN KEy(idestheader)
REFERENCES estimateheader(Id);



SELECT * from gastoslocales
// Valores en GASTOS LOCALES N- DUCHAS ESCOCESAS
SELECT * from fwdtte      		// 8
SELECT * from terminal    		// 4
SELECT * from despachantes		// 1
SELECT * from flete				// 2
SELECT * from custodia			// 4
SELECT * from gestdigdoc		// 1
SELECT * from banco				// 3
SELECT * from polizas			// 7	

SELECT * from estimateheader

SELECT * from tarifasfwds
SELECT * from flete
SELECT * from polizas




SELECT * from ncm
	

