CREATE TABLE tarifasdepositos 
(
	id SERIAL,
	depo	 char varying NOT NULL,
	contype  char varying NOT NULL,
	descarga float8 NOT NULL,
	ingreso  float8 NOT NULL,
	totingreso	float8,
	carga float8 NOT NULL,
	armado float8,
	egreso float8 NOT NULL,
	totegreso float8,
	PRIMARY KEY (id)
)

SELECT * FROM tarifasdepositos
