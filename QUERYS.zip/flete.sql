CREATE TABLE flete 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from flete  




