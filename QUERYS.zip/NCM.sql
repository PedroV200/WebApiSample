CREATE TABLE ncm 
(
	id SERIAL,
	code char varying PRIMARY KEY,
	description char varying,
	anexo char varying,
	die float8,
	te float8,
	iva float8,
	iva_ad float8,
	imp_int float8,
	licencia	char varying,
	bit_bk	char varying,
	vc		char varying,
	peso_valor	float8
)

SELECT * from ncm 

SELECT description FROM ncm WHERE code='8481.80.19.190F'


