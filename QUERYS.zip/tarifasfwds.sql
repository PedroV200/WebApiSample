CREATE TABLE tarifasfwds 
(
	id SERIAL,
	contype	 char varying NOT NULL,
	fwdfrom  char varying NOT NULL,
	costoflete float8 NOT NULL,
	costoflete040  float8,
	costoflete060	float8,
	gastos1			float8,
	gastos2			float8,
	PRIMARY KEY (id)
)

SELECT * FROM tarifasfwds
