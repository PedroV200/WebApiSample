CREATE TABLE gestdigdoc 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from gestdigdoc 




