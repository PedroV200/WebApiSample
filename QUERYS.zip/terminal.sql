CREATE TABLE terminal 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from terminal  




