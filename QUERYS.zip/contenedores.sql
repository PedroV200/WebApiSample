CREATE TABLE contenedores 
(
	id SERIAL,
	description	 char varying NOT NULL,
	weight float8 NOT NULL,
	volume  float8 NOT NULL,
	PRIMARY KEY (id)
)

SELECT * FROM contenedores
