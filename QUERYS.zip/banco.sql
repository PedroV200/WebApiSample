CREATE TABLE banco 
(
	id SERIAL PRIMARY KEY,
	description char varying
)

SELECT * from banco  




