LISTED 29_6_2023 17:30

CREATE TABLE estimateheader 
(
	Id SERIAL,
	Description	 char varying,
	EstNumber integer NOT NULL,
	EstVers integer NOT NULL,
	Own char varying NOT NULL,
	ArticleFamily	char varying NOT NULL,
	IvaExcento	bool,
		
	FreightType char varying NOT NULL,
	FreightFwd char varying NOT NULL,
	FobGrandTotal float8,
	FleteTotal	float8,
	Seguro float8,
	CantidadContenedores float8,
	Pagado float8,
	CbmTot float8,
	CifTot float8,
	IibbTot float8,
    ExtraGastosLocProyectado float8,
    c_gdespa_cif_min float8,
    c_gdespa_cif_mult float8,
    c_gdespa_cif_thrhld float8,
    c_gcust_thrshld float8,
    c_ggesdoc_mult float8,
    c_gbanc_mult float8,
    c_ncmdie_min float8,
    c_est061_thrhldmax float8,
    c_est061_thrhldmin float8,
    c_gcias424_mult float8,
	c_seguroporct float8,
	c_arancelsim float8,
	DolarBillete float8 NOT NULL,
	PolizaProv char varying,
    p_gloc_banco char varying,
    p_gloc_fwder char varying,
    p_gloc_term char varying,
    p_gloc_despa char varying,
    p_gloc_tte char varying,
    p_gloc_cust char varying,
    p_gloc_gestdigdoc char varying,
	
	oemprove1 char varying,
	oemprove2 char varying,
	oemprove3 char varying,
	oemprove4 char varying,
	oemprove5 char varying,
	oemprove6 char varying,
	oemprove7 char varying,
	
	id_polizaprov integer REFERENCES polizas (id), 				--	3			select * from polizas
	id_p_gloc_banco integer REFERENCES banco (id),				--	3			select * from banco
    id_p_gloc_fwder integer REFERENCES fwdtte (id),				--	1			select * from fwdtte
    id_p_gloc_term integer REFERENCES terminal (id),			--	1			select * from terminal
    id_p_gloc_despa integer REFERENCES despachantes (id),		--	1		select * from despachantes
    id_p_gloc_tte integer REFERENCES flete(id),					--	1				select * from flete
    id_p_gloc_cust integer REFERENCES custodia(id),				--	1			select * from custodia
    id_p_gloc_gestdigdoc integer REFERENCES gestdigdoc(id),		--	1		select * from gestdigdoc
	
	id_oemprove1 integer REFERENCES proveedores(id),			--	1		select * from proveedores
	id_oemprove2 integer REFERENCES proveedores(id),
	id_oemprove3 integer REFERENCES proveedores(id),
	id_oemprove4 integer REFERENCES proveedores(id),
	id_oemprove5 integer REFERENCES proveedores(id),
	id_oemprove6 integer REFERENCES proveedores(id),
	id_oemprove7 integer REFERENCES proveedores(id),
	

	
	htimestamp timestamp,
	PRIMARY KEY (Id)
)

ALTER TABLE estimateheader
ADD CONSTRAINT pk_code
FOREIGN KEy(id_p_gloc_fwder)
REFERENCES fwdtte(Id);




SELECT * from estimateheader

DELETE FROM estimateheader WHERE estnumber=947
DELETE FROM estimateDetails WHERE idestheader=41

SELECT * FROM estimateheader WHERE estnumber=920 ORDER BY estvers DESC

SELECT * FROM estimateheader WHERE estnumber=945 ORDER BY estvers DESC
SELECT * FROM estimateheader WHERE estnumber=945 AND estvers=1

SELECT * from estimatedetails



SELECT * from Products

CREATE TABLE estimatedetails
(
	id SERIAL PRIMARY KEY,
	Modelo char varying,
	Ncm	char varying NOT NULL,
	Pesounitxcaja float8 NOT NULL,
	Cbmxcaja	float8 NOT NULL,
	Pcsxcaja	int NOT NULL,
	Fobunit		float8 NOT NULL,
	Cantpcs		int NOT NULL,
	IdEstHeader int NOT NULL,
	ncm_die		float8,
	ncm_te		float8,
	ncm_iva		float8,
	ncm_ivaad	float8,
	sparef1		float8,
	sparef2		float8,
	sparef3		float8,
	sparef4 	float8
)


ALTER TABLE estimatedetails
ADD CONSTRAINT pk_code
FOREIGN KEy(IdEstHeader)
REFERENCES estimateheader(Id);



SELECT * from estimatedetails

SELECT * from ncm

SELECT * FROM tarifaspoliza
	
›

SELECT * FROM constantes

DELETE FROM estimatedetails WHERE modelo like '%JERROLD%'
DELETE FROM estimateheaders WHERE oemsupplier like '%J E R R O L D%'
